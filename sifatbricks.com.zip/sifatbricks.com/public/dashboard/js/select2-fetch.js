// Clients group ----------------------------------------------------
function fetchClientGroups() {
    // Get the client groups before search
    $.ajax({
        url: "/clients-group",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#client_group_id").html(html);
        },
    });

    $("#client_group_id").select2({
        ajax: {
            url: "/clients-group",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search a group",
    });
}

// Suppliers group ----------------------------------------------------
function fetchSupplierGroups() {
    // Get the supplier groups before search
    $.ajax({
        url: "/suppliers-group",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#supplier_group_id").html(html);
        },
    });

    $("#supplier_group_id").select2({
        ajax: {
            url: "/suppliers-group",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search a group",
    });
}

// Clients ----------------------------------------------------
function fetchClients() {
    $.ajax({
        url: "/clients",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.client_name + ' ' + value.phone + ' ' + value.id_no +
                    '</option>';
            });
            $(".client_id #client_id #receive_client_id").html(html);
        },
    });

    $(".client_id, #client_id, #receive_client_id").select2({
        ajax: {
            url: "/clients",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.client_name + '(' + item.phone + ')(' + item.address + ')',
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Client",
    });
}

// Suppliers ----------------------------------------------------
function fetchSuppliers() {
    $.ajax({
        url: "/suppliers",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.supplier_name +
                    "</option>";
            });
            $(".supplier_id #supplier_id").html(html);
        },
    });

    $(".supplier_id, #supplier_id").select2({
        ajax: {
            url: "/suppliers",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.supplier_name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Suppliers",
    });
}

// Accounts ----------------------------------------------------
function fetchAccounts() {
    $.ajax({
        url: "/accounts",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.title +
                    "</option>";
            });
            $(".account_id, #account_id").html(html);
        },
    });

    $(".account_id, #account_id").select2({
        ajax: {
            url: "/accounts",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.title,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Account",
    });
}

function fetchChartOfAccount() {
    $.ajax({
        url: "/get-chart-of-accounts",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#chart_account_id").html(html);
        },
    });

    $("#chart_account_id").select2({
        ajax: {
            url: "/get-chart-of-accounts",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Chart Of Account",
    });
}

function fetchPaymentMethods() {
    $.ajax({
        url: "/payment-methods",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $(".payment_id, #payment_id").html(html);
        },
    });

    $(".payment_id, #payment_id").select2({
        ajax: {
            url: "/payment-methods",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Payment Method",
    });
}

function fetchChartOfAccountGroup() {
    $.ajax({
        url: "/get-chart-of-account-groups",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#chart_group_id").html(html);
        },
    });

    $("#chart_group_id").select2({
        ajax: {
            url: "/get-chart-of-account-groups",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Chart Of Account Group",
    });
}

function fetchProjects() {
    $.ajax({
        url: "/projects",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.project_name +
                    "</option>";
            });
            $("#project_id").html(html);
        },
    });

    $("#project_id").select2({
        ajax: {
            url: "/accounts",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.project_name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Project",
    });
}

function fetchInvoices() {
    $.ajax({
        url: "/invoices",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.id +
                    "</option>";
            });
            $("#invoice_id").html(html);
        },
    });

    $("#invoice_id").select2({
        ajax: {
            url: "/invoices",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.id,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Invoice",
    });
}

function fetchReceiveCategories() {
    $.ajax({
        url: "/get-receive-categories",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#category_id").html(html);
        },
    });

    $("#category_id").select2({
        ajax: {
            url: "/get-receive-categories",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Categories",
    });
}

function fetchProducts() {
    $.ajax({
        url: "/products",
        dataType: "json",
        success: function(data) {
            console.log(data);
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value=""></option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    value.selling_price +
                    "</option>";
            });
            $("#product_search").html(html);
        },
    });

    $("#product_search").select2({
        ajax: {
            url: "/products",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {

                    if (item.selling_price == null) {
                        var selling_price = '0';
                    } else {
                        var selling_price = item.selling_price;
                    }
                    return {
                        id: item.id,
                        text: item.name + " (" + selling_price + ")",
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: " Bricks ",
    });
}

function fetchPurchaseProduct() {
    $.ajax({
        url: "/purchase/products",
        dataType: "json",
        success: function(data) {
            console.log(data);
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value=""></option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name + '(' +
                    value.buying_price + ')' +
                    "</option>";
            });
            $("#product_search").html(html);
        },
    });

    $("#product_search").select2({
        ajax: {
            url: "/purchase/products",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {

                    if (item.buying_price == null) {
                        var buying_price = '0';
                    } else {
                        var buying_price = item.buying_price;
                    }
                    return {
                        id: item.id,
                        text: item.name + " (" + buying_price + ")",
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
    });
}
//purchase product
function fetchPurchaseProduct() {
    $.ajax({
        url: "/purchase/products",
        dataType: "json",
        success: function(data) {
            console.log(data);
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value=""></option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name + '(' +
                    value.buying_price + ')' +
                    "</option>";
            });
            $("#product_search").html(html);
        },
    });

    $("#product_search").select2({
        ajax: {
            url: "/purchase/products",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {

                    if (item.buying_price == null) {
                        var buying_price = '0';
                    } else {
                        var buying_price = item.buying_price;
                    }
                    return {
                        id: item.id,
                        text: item.name + " (" + buying_price + ")",
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
    });
}
// Staffs ----------------------------------------------------
function fetchStaffs() {
    $.ajax({
        url: "/staffs",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $(".staff_id, #staff_id").html(html);

        },
    });

    $(".staff_id, #staff_id").select2({
        ajax: {
            url: "/staffs",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Select Staffs",
    });
}

function fetchExpenseCategories() {
    $.ajax({
        url: "/get-expense-categories",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#expense_category_id").html(html);
        },
    });

    $("#expense_category_id").select2({
        ajax: {
            url: "/get-expense-categories",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Categories",
    });
}

function fetchExpenseSubcategories() {
    $.ajax({
        url: "/get-expense-subcategories",
        dataType: "json",
        success: function(data) {
            var html = "";
            $.each(data, function(index, value) {
                html += '<option value="">Select</option>';
                html +=
                    '<option value="' +
                    value.id +
                    '">' +
                    value.name +
                    "</option>";
            });
            $("#subcategory_id").html(html);
        },
    });

    $("#subcategory_id").select2({
        ajax: {
            url: "/get-expense-subcategories",
            dataType: "json",
            delay: 250,
            data: function(params) {
                return {
                    search_text: params.term, // Search term entered by the user
                };
            },
            processResults: function(data) {
                var results = $.map(data, function(item) {
                    return {
                        id: item.id,
                        text: item.name,
                    };
                });

                return {
                    results: results,
                };
            },
            cache: true,
        },
        placeholder: "Search Categories",
    });
}